abstract class Task {
  public abstract String printStatus();

  public abstract int calculateResult(int balance);

}
